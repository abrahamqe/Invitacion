
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
  

// Cuenta regresiva
const countdown = () => {
    const eventDate = new Date('2025-05-25T16:00:00').getTime();
    const now = new Date().getTime();
    const diff = eventDate - now;

    if (diff < 0) {
        document.getElementById('timer').innerText = '¡Ya fue el gran día!';
        return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    document.getElementById('days').innerText = days;
};

setInterval(countdown, 1000);

// Animaciones al hacer scroll
const elements = document.querySelectorAll('.fade-in');
window.addEventListener('scroll', () => {
    elements.forEach(el => {
        const position = el.getBoundingClientRect().top;
        const screenHeight = window.innerHeight;

        if (position < screenHeight - 100) {
            el.classList.add('visible');
        }
    });
});


// Función para activar o desactivar el audio
let isPlaying = false;
const audio = document.getElementById("backgroundAudio");
const button = document.getElementById("audioButton");

function toggleAudio() {
  if (isPlaying) {
    audio.pause();
    button.innerText = " Activar Música";
  } else {
    audio.play();
    button.innerText = " Desactivar Música";
  }
  isPlaying = !isPlaying;
}

window.onload = function () {
    audio.volume = 0.5; // Volumen inicial (50%)
  };

  
  audio.loop = true; // Configura el audio para que se repita automáticamente


  // Generar notas musicales dinámicamente
const floatingNotesContainer = document.querySelector('.floating-notes');

// Array de símbolos musicales
const notes = ['♪', '♫', '♬', '♩', '♭', '♮'];

for (let i = 0; i < 20; i++) {
  const note = document.createElement('span');
  note.classList.add('note');
  note.textContent = notes[Math.floor(Math.random() * notes.length)]; // Nota aleatoria
  note.style.left = `${Math.random() * 100}%`; // Posición horizontal aleatoria
  note.style.animationDelay = `${Math.random() * 12}s`; // Retraso aleatorio
  floatingNotesContainer.appendChild(note);
}
